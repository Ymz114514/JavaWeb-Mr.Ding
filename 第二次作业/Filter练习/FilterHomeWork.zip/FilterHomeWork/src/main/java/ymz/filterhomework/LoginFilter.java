package ymz.filterhomework;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebFilter(urlPatterns = "/*")
public class LoginFilter implements Filter {
    private static final List<String> PASS_URLS = List.of("/login", "/register","/public","/LoginServlet");
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        /**
         * 在过滤器中判断用户是否登陆。
         * 在白名单中的访问路径直接放行。
         * 其他的都要判断用户是否登陆。
         */

        /**
         * 有一个特殊情况，如果只输入http://ip:8080/上下文路径 的话，
         * 会自动将去找index.html。对此，我要截获这个请求，并自动将其请求转发到login.html去。
         */

        //预处理
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse resp = (HttpServletResponse) servletResponse;

        //使用req.getServletPath()获取上下文路径后面的访问路径。
        String servletPath = req.getServletPath();
        if(servletPath.equals("/")){
            //特殊情况的处理
            req.getRequestDispatcher("/login").forward(req,resp);
            return;
        }
        if(PASS_URLS.contains(servletPath)){
            //在白名单中，直接放行
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }
        //能执行到这里，说明要进行登陆的检验了。
        /**
         * 登陆检验的思路。
         * 在这里使用req.getSession(false);
         * 这里的参数表示是否创建一个新的会话，在找不到的时候。
         * 这里我选择不创建。因为如果请求体中没有JSessionID或者已经失效的话，那么肯定是找不到Session的。
         * 而指定参数值为false的话，就不创建新的Session，而是直接返回null。
         * 于是，我们可以检测此方法返回值是否为非null来判断用户是否登陆。
         */
        if(req.getSession(false)!=null){
            //登陆过
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }
        //没登录过。直接请求转发到登录页！
        req.getRequestDispatcher("/login").forward(req,resp);
    }
}
