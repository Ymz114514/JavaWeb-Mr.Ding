package ymz.filterhomework;

import cn.hutool.json.JSON;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;

//此Servlet专门处理登陆业务
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private String account = "ymz";
    private String password = "123456";
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        /**
         * 处理从前端发过来的JSON字符串，将内容使用输入流读取后，再使用Hutool包的JSON工具将其转换为Java中的JSON对象。
         */
        StringBuilder jsonBuilder = new StringBuilder();
        String line;
        try (BufferedReader reader = req.getReader()) {
            while ((line = reader.readLine()) != null) {
                jsonBuilder.append(line);
            }
        }
        String jsonData = jsonBuilder.toString();
        JSONObject jsonObject = JSONUtil.parseObj(jsonData);

        //从JSON对象中获取我们所需的参数
        String account1 = (String) jsonObject.get("account");
        String password1 = (String) jsonObject.get("password");
        JSONObject result = JSONUtil.createObj();

        //开始校验是否登陆成功
        boolean isLogin = false;
        if(account1.equals(account)&&password1.equals(password)){
            isLogin = true;
            req.getSession(true).setAttribute("account",account1);
        }
        result.putOpt("result",isLogin);
        resp.getWriter().println(result);
    }
}
