package ymz.listenerhomework.Listener;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;
import ymz.listenerhomework.log.RequestLog;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

@WebListener
public class RequestListenerTest implements ServletRequestListener {
    //定义一个静态的BufferedWriter对象，用于写入日志文件
    private static final BufferedWriter writer;
    //静态代码块，初始化BufferedWriter对象
    static {
        try {
            //我本来想写src/main/resources/requestLogs.txt 这个相对路径的，但是不知道为什么Tomcat会提示找不到。。。迫不得已，只能用绝对路径了。
            writer = new BufferedWriter(new FileWriter("D:\\AllCode\\Java\\Big\\ListenerHomework\\src\\main\\resources\\requestLogs.txt"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        //请求即将销毁，将Log对象从请求域对象中取出，并使用输出流将日志信息输出到本地的requestLogs.txt这个文件中去。
        HttpServletRequest req = (HttpServletRequest)sre.getServletRequest();
        RequestLog log = (RequestLog)req.getAttribute("log");
        try {
            writer.write(log.toString());
            writer.newLine();
            writer.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        //请求开始时，创建Log对象并存入请求域对象中
        HttpServletRequest req = (HttpServletRequest)sre.getServletRequest();
        RequestLog log = new RequestLog(req);
        req.setAttribute("log", log);
    }
}
