package ymz.listenerhomework.log;

import jakarta.servlet.http.HttpServletRequest;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RequestLog {
    private long start;
    private long duration;
    private String IPAddress;
    private String requestURL;
    private String requestMethod;
    private String requestParams;
    private String UserAgent;

    public RequestLog(HttpServletRequest req){
        //从请求对象中获取Http请求信息
        start = System.currentTimeMillis();
        IPAddress = req.getRemoteAddr();
        requestURL = req.getRequestURI();
        requestMethod = req.getMethod();
        requestParams = req.getQueryString();
        UserAgent = req.getHeader("User-Agent");
    }

    public void getDuration(){
        //获取请求持续时间
        long end = System.currentTimeMillis();
        duration = end - start;
    }

    @Override
    public String toString() {
        //输出日志时，才计算请求持续时间
        //这里我将日志信息格式化输出
        getDuration();
        Date now = new Date(start);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String startTime = sdf.format(now);
        return
                "["+startTime+"]"+":"+
                "  IPAddress='" + IPAddress + '\'' +
                ", requestURL='" + requestURL + '\'' +
                ", requestMethod='" + requestMethod + '\'' +
                ", requestParams='" + requestParams + '\'' +
                ", UserAgent='" + UserAgent + '\'' +
                ", duration=" + duration +"ms";
    }
}
