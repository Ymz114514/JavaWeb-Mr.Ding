import java.io.Serial;
import java.io.Serializable;

public class Person implements Serializable {
    @Serial
    private static final long serialVersionUID = -8098248935980398369L;
    private Integer age;
    private String name;
    transient private Gender gender;


    public Person() {
    }

    public Person(Integer age, String name, Gender gender) {
        this.age = age;
        this.name = name;
        this.gender = gender;
    }


    public Integer getAge() {
        return age;
    }


    public void setAge(Integer age) {
        this.age = age;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public Gender getGender() {
        return gender;
    }


    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public String toString() {
        return "Person{age = " + age + ", name = " + name + ", gender = " + gender + "}";
    }
}
enum Gender{
    boy,girl
}
