import org.junit.Test;

import java.io.*;

public class Main {
    @Test
    public void testSerialization() throws IOException {
        //测试序列化
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("./src/main/resources/person.ser"));
        Person ymz = new Person(21, "杨明璋", Gender.boy);
        oos.writeObject(ymz);
        oos.close();
    }
    @Test
    public void testDeserialization() throws IOException, ClassNotFoundException {
        //测试反序列化
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("./src/main/resources/person.ser"));
        Person obj = (Person) ois.readObject();
        System.out.println(obj);
        ois.close();
    }
}